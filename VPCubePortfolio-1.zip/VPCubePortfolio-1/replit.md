# Replit.md - 3D Interactive Portfolio

## Overview

This is a modern, interactive 3D portfolio website built with React, Three.js, and Express. The application features an immersive 3D experience with floating navigation cubes, dynamic camera movements, and interactive sections showcasing personal and professional content. The architecture follows a full-stack approach with a React frontend using Three.js for 3D rendering and an Express backend with PostgreSQL database integration.

**Recent Changes (January 29, 2025):**
- Updated entire theme to black and golden gradient with varied golden tones (#ffd700, #f59e0b, #b8860b, #d4af37)
- Applied consistent color scheme across all 3D materials, UI components, and shader effects
- Maintained visual hierarchy with different grades of golden colors for various elements

## User Preferences

Preferred communication style: Simple, everyday language.
Theme preference: Black and golden gradient theme with varied golden tones.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety
- **3D Rendering**: Three.js via @react-three/fiber for declarative 3D scenes
- **State Management**: Zustand stores for global state (portfolio navigation, audio controls)
- **Styling**: Tailwind CSS with custom design system and shadcn/ui components
- **Build Tool**: Vite for fast development and optimized production builds
- **3D Enhancements**: @react-three/drei for additional 3D utilities and helpers

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Development**: Hot module replacement via Vite integration in development mode

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Type-safe schema definitions in shared directory
- **Migrations**: Drizzle-kit for database schema management
- **Connection**: Neon Database serverless driver for PostgreSQL connectivity

## Key Components

### 3D Scene Architecture
- **Scene Management**: Central Scene component orchestrating all 3D elements
- **Navigation System**: Interactive 3D cube with clickable faces for section navigation
- **Camera Control**: Custom camera movement system with smooth transitions between sections
- **Lighting**: Dynamic lighting setup with multiple directional lights for depth
- **Post-Processing**: Bloom effects and visual enhancements via Three.js post-processing

### Interactive Elements
- **Navigation Cube**: Central floating cube with 6 faces representing different portfolio sections
- **Floating Islands**: Ambient 3D elements for visual interest and depth
- **Particle Systems**: Dynamic particle effects for visual enhancement
- **Audio Integration**: Background music and interaction sound effects

### UI Components
- **Loading Screen**: Animated loading experience with progress indication
- **Intro Animation**: Dramatic text reveal animation on initial load
- **Navigation Bar**: Traditional 2D navigation overlay for accessibility
- **Section Content**: Dedicated 3D representations for About, Projects, Skills, and Contact sections

### State Management
- **Portfolio Store**: Current section tracking, loading states, navigation control
- **Audio Store**: Background music control, sound effects, mute functionality
- **Responsive Design**: Mobile-first approach with responsive 3D interactions

## Data Flow

### Frontend Data Flow
1. Application initialization loads 3D scene and assets
2. User interactions trigger state changes in Zustand stores
3. State changes drive camera movements and section transitions
4. 3D components respond to state changes with smooth animations
5. Audio system provides feedback for user interactions

### Backend Data Flow
1. Express server handles API requests with middleware logging
2. Route handlers interact with storage layer (currently in-memory)
3. Database operations use Drizzle ORM for type safety
4. Response data flows back through Express middleware
5. Error handling provides consistent API responses

### Real-time Interactions
- Mouse movement influences camera and object rotations
- Keyboard navigation for accessibility
- Touch support for mobile devices
- Audio feedback for enhanced user experience

## External Dependencies

### Core Libraries
- **React Ecosystem**: React 18, React DOM, TypeScript support
- **3D Graphics**: Three.js, @react-three/fiber, @react-three/drei, @react-three/postprocessing
- **UI Framework**: Radix UI primitives, Tailwind CSS, class-variance-authority
- **State Management**: Zustand for lightweight global state
- **Database**: Drizzle ORM, @neondatabase/serverless, PostgreSQL

### Development Tools
- **Build System**: Vite with React plugin, TypeScript, and GLSL shader support
- **Code Quality**: ESLint integration via @replit/vite-plugin-runtime-error-modal
- **Development**: tsx for TypeScript execution, hot module replacement

### Audio and Media
- **Audio Files**: MP3, OGG, WAV support for background music and sound effects
- **3D Models**: GLTF/GLB model loading capabilities
- **Fonts**: Inter font family via @fontsource/inter

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized production bundle to `dist/public`
- **Backend**: esbuild compiles TypeScript server code to `dist/index.js`
- **Assets**: Static assets and 3D models bundled with frontend build
- **Environment**: Production mode detected via NODE_ENV variable

### Development Workflow
- **Local Development**: Concurrent frontend (Vite) and backend (tsx) development servers
- **Hot Reload**: Vite HMR for instant frontend updates
- **Database**: Drizzle-kit for schema changes and migrations
- **Type Safety**: Shared TypeScript types between frontend and backend

### Production Considerations
- **Database**: PostgreSQL via Neon Database with connection pooling
- **Static Assets**: Optimized bundle with code splitting and lazy loading
- **Performance**: Three.js scene optimization for smooth 60fps rendering
- **Accessibility**: Keyboard navigation and screen reader support
- **Browser Support**: Modern browsers with WebGL support required

### Environment Configuration
- **Database**: DATABASE_URL environment variable for PostgreSQL connection
- **Build**: Separate development and production build configurations
- **Assets**: Public directory structure for 3D models, audio, and static files