import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import "@fontsource/inter";
import "./index.css";

// Import our components
import Scene from "./components/3d/Scene";
import IntroText from "./components/ui/IntroText";
import LoadingScreen from "./components/ui/LoadingScreen";
import Navigation from "./components/ui/Navigation";
import { usePortfolio } from "./lib/stores/usePortfolio";
import { useAudio } from "./lib/stores/useAudio";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
  },
});

function AppContent() {
  const { currentSection, isLoading, setLoading } = usePortfolio();
  const [showIntro, setShowIntro] = useState(true);
  const { setBackgroundMusic } = useAudio();

  useEffect(() => {
    // Load background music
    const audio = new Audio('/sounds/background.mp3');
    audio.loop = true;
    audio.volume = 0.3;
    setBackgroundMusic(audio);

    // Hide loading screen after a delay
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    // Hide intro after animation
    const introTimer = setTimeout(() => {
      setShowIntro(false);
    }, 4000);

    return () => {
      clearTimeout(timer);
      clearTimeout(introTimer);
    };
  }, [setBackgroundMusic, setLoading]);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="w-full h-screen relative overflow-hidden bg-gray-900">
      {/* Intro Animation */}
      {showIntro && <IntroText />}
      
      {/* 3D Scene */}
      <div className="absolute inset-0">
        <Canvas
          shadows
          camera={{
            position: [0, 2, 8],
            fov: 45,
            near: 0.1,
            far: 1000
          }}
          gl={{
            antialias: true,
            powerPreference: "high-performance",
            alpha: false
          }}
        >
          <color attach="background" args={["#000000"]} />
          <Suspense fallback={null}>
            <Scene />
          </Suspense>
        </Canvas>
      </div>

      {/* UI Overlay */}
      {!showIntro && <Navigation />}
      
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/20 pointer-events-none" />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
    </QueryClientProvider>
  );
}

export default App;
