import { useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { usePortfolio } from "../lib/stores/usePortfolio";
import * as THREE from "three";

export function useCamera(camera: THREE.Camera) {
  const { currentSection } = usePortfolio();

  // Define camera positions for each section
  const cameraPositions = {
    home: new THREE.Vector3(0, 2, 8),
    about: new THREE.Vector3(6, 2, 6),
    projects: new THREE.Vector3(-6, 2, 6),
    skills: new THREE.Vector3(0, 4, -6),
    contact: new THREE.Vector3(0, 0, 10)
  };

  // Define camera targets (what the camera looks at)
  const cameraTargets = {
    home: new THREE.Vector3(0, 0, 0),
    about: new THREE.Vector3(4, 0, 0),
    projects: new THREE.Vector3(-4, 0, 0),
    skills: new THREE.Vector3(0, 0, -4),
    contact: new THREE.Vector3(0, 0, 4)
  };

  useFrame((state, delta) => {
    const targetPosition = cameraPositions[currentSection as keyof typeof cameraPositions] || cameraPositions.home;
    const targetLookAt = cameraTargets[currentSection as keyof typeof cameraTargets] || cameraTargets.home;

    // Smooth camera movement
    camera.position.lerp(targetPosition, delta * 2);
    
    // Smooth camera rotation (look at target)
    const direction = new THREE.Vector3();
    direction.subVectors(targetLookAt, camera.position).normalize();
    
    const currentDirection = new THREE.Vector3(0, 0, -1);
    currentDirection.applyQuaternion(camera.quaternion);
    
    const targetQuaternion = new THREE.Quaternion();
    targetQuaternion.setFromUnitVectors(currentDirection, direction);
    
    camera.quaternion.slerp(targetQuaternion, delta * 2);
  });
}
