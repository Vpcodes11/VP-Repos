import { useRef, useEffect } from "react";
import { extend, useFrame } from "@react-three/fiber";
import * as THREE from "three";

// Custom glow material shader
const GlowMaterialImpl = {
  uniforms: {
    time: { value: 0 },
    color: { value: new THREE.Color(0xffd700) },
    glowIntensity: { value: 1.0 },
    opacity: { value: 1.0 }
  },
  vertexShader: `
    varying vec2 vUv;
    varying vec3 vPosition;
    varying vec3 vNormal;
    
    void main() {
      vUv = uv;
      vPosition = position;
      vNormal = normal;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform float time;
    uniform vec3 color;
    uniform float glowIntensity;
    uniform float opacity;
    
    varying vec2 vUv;
    varying vec3 vPosition;
    varying vec3 vNormal;
    
    void main() {
      float glow = sin(time * 2.0) * 0.5 + 0.5;
      
      // Create golden gradient effect
      vec3 gold1 = vec3(1.0, 0.843, 0.0); // #ffd700
      vec3 gold2 = vec3(0.964, 0.62, 0.043); // #f59e0b
      vec3 gold3 = vec3(0.831, 0.686, 0.216); // #d4af37
      
      // Multi-layer gradient based on UV and time
      float gradientFactor = (sin(vUv.x * 3.14159 + time) + sin(vUv.y * 3.14159 + time * 0.7)) * 0.5 + 0.5;
      vec3 gradientColor = mix(mix(gold2, gold1, gradientFactor), gold3, glow * 0.3);
      
      vec3 glowColor = mix(color, gradientColor, 0.8) * (1.0 + glow * glowIntensity);
      
      // Add some edge glow effect
      float fresnel = 1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
      glowColor += gradientColor * fresnel * 0.5;
      
      gl_FragColor = vec4(glowColor, opacity);
    }
  `
};

class GlowMaterial extends THREE.ShaderMaterial {
  constructor(props: any = {}) {
    super({
      uniforms: { ...GlowMaterialImpl.uniforms },
      vertexShader: GlowMaterialImpl.vertexShader,
      fragmentShader: GlowMaterialImpl.fragmentShader,
      transparent: true,
      ...props
    });

    // Set initial values
    if (props.color) this.uniforms.color.value = new THREE.Color(props.color);
    if (props.glowIntensity !== undefined) this.uniforms.glowIntensity.value = props.glowIntensity;
    if (props.opacity !== undefined) this.uniforms.opacity.value = props.opacity;
  }
}

extend({ GlowMaterial });

declare global {
  namespace JSX {
    interface IntrinsicElements {
      glowMaterial: any;
    }
  }
}

export default function GlowMaterialComponent(props: any) {
  const materialRef = useRef<GlowMaterial>(null);

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uniforms.time.value = state.clock.elapsedTime;
    }
  });

  return <glowMaterial ref={materialRef} {...props} />;
}
