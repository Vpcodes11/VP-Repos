import { useRef } from "react";
import { extend, useFrame } from "@react-three/fiber";
import * as THREE from "three";

// Custom glass material shader
const GlassMaterialImpl = {
  uniforms: {
    time: { value: 0 },
    color: { value: new THREE.Color(0xffd700) },
    opacity: { value: 0.3 },
    refractionRatio: { value: 0.98 }
  },
  vertexShader: `
    varying vec2 vUv;
    varying vec3 vPosition;
    varying vec3 vNormal;
    varying vec3 vReflect;
    varying vec3 vRefract;
    
    void main() {
      vUv = uv;
      vPosition = position;
      vNormal = normalize(normalMatrix * normal);
      
      vec3 worldPosition = (modelMatrix * vec4(position, 1.0)).xyz;
      vec3 cameraToVertex = normalize(worldPosition - cameraPosition);
      
      vReflect = reflect(cameraToVertex, vNormal);
      vRefract = refract(cameraToVertex, vNormal, 0.98);
      
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform float time;
    uniform vec3 color;
    uniform float opacity;
    
    varying vec2 vUv;
    varying vec3 vPosition;
    varying vec3 vNormal;
    varying vec3 vReflect;
    varying vec3 vRefract;
    
    void main() {
      // Create a subtle wave effect with golden gradient
      float wave = sin(vPosition.x * 2.0 + time) * sin(vPosition.y * 2.0 + time) * 0.1;
      
      // Fresnel effect for glass-like appearance
      float fresnel = 1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
      
      // Create golden gradient effect
      vec3 gold1 = vec3(1.0, 0.843, 0.0); // #ffd700
      vec3 gold2 = vec3(0.722, 0.525, 0.043); // #b8860b
      vec3 gradientColor = mix(gold2, gold1, fresnel + wave);
      
      vec3 glassColor = mix(color, gradientColor, 0.7);
      float glassOpacity = opacity + fresnel * 0.3;
      
      gl_FragColor = vec4(glassColor, glassOpacity);
    }
  `
};

class GlassMaterial extends THREE.ShaderMaterial {
  constructor(props: any = {}) {
    super({
      uniforms: { ...GlassMaterialImpl.uniforms },
      vertexShader: GlassMaterialImpl.vertexShader,
      fragmentShader: GlassMaterialImpl.fragmentShader,
      transparent: true,
      side: THREE.DoubleSide,
      ...props
    });

    // Set initial values
    if (props.color) this.uniforms.color.value = new THREE.Color(props.color);
    if (props.opacity !== undefined) this.uniforms.opacity.value = props.opacity;
  }
}

extend({ GlassMaterial });

declare global {
  namespace JSX {
    interface IntrinsicElements {
      glassMaterial: any;
    }
  }
}

export default function GlassMaterialComponent(props: any) {
  const materialRef = useRef<GlassMaterial>(null);

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uniforms.time.value = state.clock.elapsedTime;
    }
  });

  return <glassMaterial ref={materialRef} {...props} />;
}
