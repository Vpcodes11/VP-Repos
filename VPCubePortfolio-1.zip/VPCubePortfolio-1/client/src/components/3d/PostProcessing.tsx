import { useThree, extend } from "@react-three/fiber";
import { EffectComposer, RenderPass, UnrealBloomPass } from "three/examples/jsm/Addons.js";
import { useRef, useEffect } from "react";
import * as THREE from "three";

// Extend the composer for react-three-fiber
extend({ EffectComposer, RenderPass, UnrealBloomPass });

export default function PostProcessing() {
  const { gl, scene, camera } = useThree();
  const composerRef = useRef<EffectComposer>();

  useEffect(() => {
    if (!composerRef.current) {
      // Create effect composer
      const composer = new EffectComposer(gl);
      
      // Add render pass
      const renderPass = new RenderPass(scene, camera);
      composer.addPass(renderPass);
      
      // Add bloom pass for glow effects
      const bloomPass = new UnrealBloomPass(
        new THREE.Vector2(window.innerWidth, window.innerHeight),
        0.5, // strength
        0.4, // radius
        0.85 // threshold
      );
      composer.addPass(bloomPass);
      
      composerRef.current = composer;
    }

    // Handle resize
    const handleResize = () => {
      if (composerRef.current) {
        composerRef.current.setSize(window.innerWidth, window.innerHeight);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [gl, scene, camera]);

  // Use the composer in the render loop
  useThree(({ gl }) => {
    gl.autoClear = false;
    return () => {
      if (composerRef.current) {
        composerRef.current.render();
      }
    };
  });

  return null;
}
