import { useFrame, useThree } from "@react-three/fiber";
import { useRef, useEffect } from "react";
import * as THREE from "three";
import NavigationCube from "./NavigationCube";
import FloatingIsland from "./FloatingIsland";
import Lights from "./Lights";
import PostProcessing from "./PostProcessing";
import AboutSection from "../sections/AboutSection";
import ProjectsSection from "../sections/ProjectsSection";
import SkillsSection from "../sections/SkillsSection";
import ContactSection from "../sections/ContactSection";
import { usePortfolio } from "../../lib/stores/usePortfolio";
import { useCamera } from "../../hooks/useCamera";
import { useMouseParallax } from "../../hooks/useMouseParallax";

export default function Scene() {
  const { camera } = useThree();
  const { currentSection } = usePortfolio();
  const sceneRef = useRef<THREE.Group>(null);
  
  // Custom hooks for camera and mouse interactions
  useCamera(camera);
  const mousePosition = useMouseParallax();

  // Subtle scene rotation based on mouse movement
  useFrame((state, delta) => {
    if (sceneRef.current && mousePosition) {
      const targetRotationY = mousePosition.x * 0.02;
      const targetRotationX = mousePosition.y * 0.01;
      
      sceneRef.current.rotation.y = THREE.MathUtils.lerp(
        sceneRef.current.rotation.y,
        targetRotationY,
        delta * 2
      );
      sceneRef.current.rotation.x = THREE.MathUtils.lerp(
        sceneRef.current.rotation.x,
        targetRotationX,
        delta * 2
      );
    }
  });

  return (
    <group ref={sceneRef}>
      {/* Lighting */}
      <Lights />
      
      {/* Main navigation cube */}
      <NavigationCube />
      
      {/* Floating islands for decoration */}
      <FloatingIsland position={[-15, -2, -10]} scale={0.5} />
      <FloatingIsland position={[12, 3, -8]} scale={0.3} />
      <FloatingIsland position={[8, -3, 5]} scale={0.4} />
      
      {/* Section content based on current selection */}
      {currentSection === 'about' && <AboutSection />}
      {currentSection === 'projects' && <ProjectsSection />}
      {currentSection === 'skills' && <SkillsSection />}
      {currentSection === 'contact' && <ContactSection />}
      
      {/* Post-processing effects */}
      <PostProcessing />
    </group>
  );
}
