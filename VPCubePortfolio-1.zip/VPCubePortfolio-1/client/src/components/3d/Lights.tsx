import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export default function Lights() {
  const lightRef = useRef<THREE.DirectionalLight>(null);

  useFrame((state) => {
    if (lightRef.current) {
      // Gentle light movement
      lightRef.current.position.x = Math.sin(state.clock.elapsedTime * 0.3) * 5;
      lightRef.current.position.z = Math.cos(state.clock.elapsedTime * 0.3) * 5;
    }
  });

  return (
    <>
      {/* Ambient lighting */}
      <ambientLight intensity={0.3} color="#ffd700" />
      
      {/* Main directional light */}
      <directionalLight
        ref={lightRef}
        position={[5, 10, 5]}
        intensity={1.5}
        color="#ffffff"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={10}
        shadow-camera-bottom={-10}
      />
      
      {/* Fill light */}
      <directionalLight
        position={[-5, 5, -5]}
        intensity={0.8}
        color="#b8860b"
      />
      
      {/* Rim light */}
      <directionalLight
        position={[0, -5, -10]}
        intensity={0.5}
        color="#f59e0b"
      />

      {/* Point lights for accent */}
      <pointLight
        position={[10, 5, 10]}
        intensity={1}
        color="#ffd700"
        distance={20}
        decay={2}
      />
      
      <pointLight
        position={[-10, -5, -10]}
        intensity={0.8}
        color="#b8860b"
        distance={15}
        decay={2}
      />
    </>
  );
}
