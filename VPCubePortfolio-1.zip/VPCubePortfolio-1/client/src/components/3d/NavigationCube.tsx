import { useRef, useState } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import * as THREE from "three";
import { usePortfolio } from "../../lib/stores/usePortfolio";
import { useAudio } from "../../lib/stores/useAudio";
import GlowMaterial from "../../shaders/GlowMaterial";
import GlassMaterial from "../../shaders/glassMaterial";

export default function NavigationCube() {
  const cubeRef = useRef<THREE.Group>(null);
  const { setCurrentSection, currentSection } = usePortfolio();
  const { playHit } = useAudio();
  const [hoveredFace, setHoveredFace] = useState<string | null>(null);
  
  // Auto-rotate the cube
  useFrame((state, delta) => {
    if (cubeRef.current) {
      cubeRef.current.rotation.y += delta * 0.2;
      cubeRef.current.rotation.x += delta * 0.1;
      
      // Gentle floating motion
      cubeRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
    }
  });

  const handleFaceClick = (section: string) => {
    setCurrentSection(section as any);
    playHit();
  };

  const handleFaceHover = (section: string | null) => {
    setHoveredFace(section);
  };

  // Cube faces configuration
  const faces = [
    { section: 'about', position: [0, 0, 1.5] as [number, number, number], rotation: [0, 0, 0] as [number, number, number], text: 'ABOUT' },
    { section: 'projects', position: [1.5, 0, 0] as [number, number, number], rotation: [0, Math.PI / 2, 0] as [number, number, number], text: 'PROJECTS' },
    { section: 'skills', position: [0, 0, -1.5] as [number, number, number], rotation: [0, Math.PI, 0] as [number, number, number], text: 'SKILLS' },
    { section: 'contact', position: [-1.5, 0, 0] as [number, number, number], rotation: [0, -Math.PI / 2, 0] as [number, number, number], text: 'CONTACT' },
    { section: 'top', position: [0, 1.5, 0] as [number, number, number], rotation: [-Math.PI / 2, 0, 0] as [number, number, number], text: 'VP' },
    { section: 'bottom', position: [0, -1.5, 0] as [number, number, number], rotation: [Math.PI / 2, 0, 0] as [number, number, number], text: 'DEV' },
  ];

  return (
    <group ref={cubeRef} position={[0, 0, 0]}>
      {/* Glass cube structure */}
      <mesh>
        <boxGeometry args={[3, 3, 3]} />
        <GlassMaterial 
          transparent 
          opacity={hoveredFace ? 0.6 : 0.3}
          color="#ffd700"
        />
      </mesh>

      {/* Glowing edges */}
      <lineSegments>
        <edgesGeometry args={[new THREE.BoxGeometry(3, 3, 3)]} />
        <lineBasicMaterial color="#ffd700" transparent opacity={0.8} />
      </lineSegments>

      {/* Interactive faces */}
      {faces.map((face, index) => (
        <group key={face.section} position={face.position} rotation={face.rotation}>
          {/* Invisible clickable area */}
          <mesh
            onClick={() => handleFaceClick(face.section)}
            onPointerEnter={() => handleFaceHover(face.section)}
            onPointerLeave={() => handleFaceHover(null)}
          >
            <planeGeometry args={[2.8, 2.8]} />
            <meshBasicMaterial transparent opacity={0} />
          </mesh>

          {/* Face glow effect */}
          {hoveredFace === face.section && (
            <mesh position={[0, 0, -0.01]}>
              <planeGeometry args={[2.5, 2.5]} />
              <GlowMaterial 
                color="#ffd700" 
                transparent 
                opacity={0.3}
                glowIntensity={2}
              />
            </mesh>
          )}

          {/* Face text */}
          <Text
            position={[0, 0, 0.01]}
            fontSize={0.3}
            color={hoveredFace === face.section ? "#ffffff" : "#ffd700"}
            anchorX="center"
            anchorY="middle"
            font="/fonts/inter.json"
          >
            {face.text}
          </Text>

          {/* Active section indicator */}
          {currentSection === face.section && (
            <mesh position={[0, 0, 0.02]}>
              <ringGeometry args={[0.8, 1.0, 32]} />
              <GlowMaterial 
                color="#f59e0b" 
                transparent 
                opacity={0.8}
                glowIntensity={3}
              />
            </mesh>
          )}
        </group>
      ))}

      {/* Inner core glow */}
      <mesh>
        <sphereGeometry args={[0.5, 32, 32]} />
        <GlowMaterial 
          color="#ffd700" 
          transparent 
          opacity={0.6}
          glowIntensity={1.5}
        />
      </mesh>
    </group>
  );
}
