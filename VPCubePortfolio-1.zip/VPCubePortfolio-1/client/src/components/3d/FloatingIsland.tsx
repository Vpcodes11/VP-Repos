import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface FloatingIslandProps {
  position: [number, number, number];
  scale: number;
}

export default function FloatingIsland({ position, scale }: FloatingIslandProps) {
  const islandRef = useRef<THREE.Group>(null);
  const baseY = position[1];
  const floatSpeed = Math.random() * 0.5 + 0.3;
  const rotationSpeed = Math.random() * 0.1 + 0.05;

  useFrame((state) => {
    if (islandRef.current) {
      // Floating motion
      islandRef.current.position.y = baseY + Math.sin(state.clock.elapsedTime * floatSpeed) * 0.5;
      
      // Gentle rotation
      islandRef.current.rotation.y += rotationSpeed * 0.01;
    }
  });

  return (
    <group ref={islandRef} position={position} scale={scale}>
      {/* Main island body */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[2, 1.5, 0.8, 8]} />
        <meshStandardMaterial 
          color="#1a1a00" 
          roughness={0.8} 
          metalness={0.2}
        />
      </mesh>

      {/* Floating rocks */}
      {Array.from({ length: 3 }, (_, i) => {
        const angle = (i / 3) * Math.PI * 2;
        const radius = 1.5 + Math.random() * 0.5;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        const y = Math.random() * 0.5 + 0.2;

        return (
          <mesh key={i} position={[x, y, z]}>
            <dodecahedronGeometry args={[0.2 + Math.random() * 0.1]} />
            <meshStandardMaterial 
              color="#2d2d0a" 
              roughness={0.9} 
              metalness={0.1}
            />
          </mesh>
        );
      })}

      {/* Glowing crystals */}
      {Array.from({ length: 2 }, (_, i) => {
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.random() * 1.2;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;

        return (
          <mesh key={`crystal-${i}`} position={[x, 0.3, z]}>
            <coneGeometry args={[0.1, 0.4, 6]} />
            <meshStandardMaterial 
              color="#ffd700" 
              emissive="#ffd700"
              emissiveIntensity={0.3}
              transparent
              opacity={0.8}
            />
          </mesh>
        );
      })}
    </group>
  );
}
