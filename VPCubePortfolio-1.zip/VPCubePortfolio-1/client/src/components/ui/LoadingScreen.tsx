import { useEffect, useState } from "react";

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const [text, setText] = useState("Initializing...");

  useEffect(() => {
    const texts = [
      "Initializing...",
      "Loading 3D Models...",
      "Preparing Experience...",
      "Almost Ready..."
    ];

    let currentIndex = 0;
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = Math.min(prev + Math.random() * 15 + 5, 100);
        
        // Update text based on progress
        const textIndex = Math.floor((newProgress / 100) * texts.length);
        if (textIndex !== currentIndex && textIndex < texts.length) {
          currentIndex = textIndex;
          setText(texts[textIndex]);
        }
        
        return newProgress;
      });
    }, 150);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
      <div className="text-center max-w-md w-full px-8">
        {/* Logo/Title */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">VP</h1>
          <p className="text-yellow-400 text-sm tracking-wider">PORTFOLIO</p>
        </div>

        {/* Progress bar */}
        <div className="relative w-full h-1 bg-gray-700 rounded-full mb-6 overflow-hidden">
          <div 
            className="absolute left-0 top-0 h-full bg-gradient-to-r from-yellow-400 via-amber-400 via-yellow-500 to-amber-500 rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
          
          {/* Glowing effect */}
          <div 
            className="absolute left-0 top-0 h-full bg-gradient-to-r from-yellow-400 via-amber-400 via-yellow-500 to-amber-500 rounded-full opacity-50 blur-sm transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Loading text */}
        <p className="text-gray-400 text-sm mb-2">{text}</p>
        <p className="text-yellow-400 text-xs">{Math.round(progress)}%</p>

        {/* Animated dots */}
        <div className="flex justify-center space-x-1 mt-6">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"
              style={{
                animationDelay: `${i * 0.2}s`,
                animationDuration: '1s'
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
