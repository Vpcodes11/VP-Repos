import { useEffect, useState } from "react";

export default function IntroText() {
  const [visible, setVisible] = useState(false);
  const [glowing, setGlowing] = useState(false);

  useEffect(() => {
    // Fade in animation
    const timer1 = setTimeout(() => setVisible(true), 500);
    
    // Glow effect
    const timer2 = setTimeout(() => setGlowing(true), 1000);
    
    // Flicker effect
    const flickerInterval = setInterval(() => {
      setGlowing(false);
      setTimeout(() => setGlowing(true), 100);
    }, 2000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearInterval(flickerInterval);
    };
  }, []);

  return (
    <div className={`
      fixed inset-0 z-50 flex items-center justify-center
      bg-gradient-to-br from-black via-yellow-900 via-amber-900 to-black
      transition-opacity duration-2000 ${visible ? 'opacity-100' : 'opacity-0'}
    `}>
      <div className="text-center">
        <h1 className={`
          text-6xl md:text-8xl font-bold mb-4
          bg-gradient-to-r from-yellow-400 via-yellow-300 via-amber-400 via-yellow-500 to-yellow-400 bg-clip-text text-transparent
          transition-all duration-500
          ${glowing ? 'drop-shadow-[0_0_30px_rgba(255,215,0,0.8)]' : ''}
        `}>
          VAIBHAV PAMNANI
        </h1>
        
        <p className={`
          text-xl md:text-2xl text-yellow-200 font-light tracking-wider
          transition-all duration-500 delay-500
          ${glowing ? 'drop-shadow-[0_0_15px_rgba(255,215,0,0.5)]' : ''}
        `}>
          Web Designer & Developer
        </p>
        
        {/* Animated particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 20 }, (_, i) => (
            <div
              key={i}
              className={`
                absolute w-1 h-1 bg-yellow-400 rounded-full opacity-60
                animate-ping
              `}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
