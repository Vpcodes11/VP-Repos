import { usePortfolio } from "../../lib/stores/usePortfolio";
import { useAudio } from "../../lib/stores/useAudio";

export default function Navigation() {
  const { currentSection, setCurrentSection } = usePortfolio();
  const { isMuted, toggleMute } = useAudio();

  const sections = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'about', label: 'About', icon: '👨‍💼' },
    { id: 'projects', label: 'Projects', icon: '💼' },
    { id: 'skills', label: 'Skills', icon: '⚡' },
    { id: 'contact', label: 'Contact', icon: '📧' },
  ];

  return (
    <>
      {/* Main Navigation */}
      <nav className="fixed top-6 left-1/2 transform -translate-x-1/2 z-40">
        <div className="bg-gradient-to-r from-black/90 via-yellow-900/20 to-black/90 backdrop-blur-md rounded-full px-6 py-3 border border-yellow-400/30 shadow-[0_0_20px_rgba(255,215,0,0.2)]">
          <div className="flex items-center space-x-6">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setCurrentSection(section.id as any)}
                className={`
                  flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-300
                  ${currentSection === section.id
                    ? 'bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black shadow-lg shadow-yellow-400/30'
                    : 'text-yellow-200 hover:text-yellow-400 hover:bg-gradient-to-r hover:from-yellow-900/30 hover:to-amber-900/30'
                  }
                `}
              >
                <span className="text-sm">{section.icon}</span>
                <span className="text-sm font-medium hidden md:inline">
                  {section.label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Controls */}
      <div className="fixed top-6 right-6 z-40 flex flex-col space-y-3">
        {/* Sound toggle */}
        <button
          onClick={toggleMute}
          className={`
            p-3 rounded-full transition-all duration-300 backdrop-blur-md border
            ${isMuted
              ? 'bg-red-500/20 border-red-400/30 text-red-400'
              : 'bg-yellow-400/20 border-yellow-400/30 text-yellow-400'
            }
            hover:scale-110 hover:shadow-lg
          `}
        >
          {isMuted ? '🔇' : '🔊'}
        </button>

        {/* Info button */}
        <button className="p-3 rounded-full bg-black/80 backdrop-blur-md border border-gray-600/30 text-yellow-200 hover:text-yellow-400 hover:scale-110 transition-all duration-300">
          ℹ️
        </button>
      </div>

      {/* Current section indicator */}
      <div className="fixed bottom-6 left-6 z-40">
        <div className="bg-gradient-to-br from-black/80 via-yellow-900/10 to-black/80 backdrop-blur-md rounded-lg px-4 py-2 border border-yellow-400/30 shadow-[0_0_15px_rgba(255,215,0,0.1)]">
          <p className="text-yellow-400 text-sm font-medium">
            {sections.find(s => s.id === currentSection)?.label || 'Home'}
          </p>
        </div>
      </div>

      {/* Instructions */}
      <div className="fixed bottom-6 right-6 z-40">
        <div className="bg-black/80 backdrop-blur-md rounded-lg px-4 py-2 border border-gray-600/30 max-w-xs">
          <p className="text-yellow-200 text-xs">
            Click on the cube faces or use navigation above
          </p>
        </div>
      </div>
    </>
  );
}
