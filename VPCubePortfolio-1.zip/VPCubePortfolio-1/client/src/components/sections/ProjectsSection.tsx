import { Text, Box } from "@react-three/drei";
import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useAudio } from "../../lib/stores/useAudio";

export default function ProjectsSection() {
  const groupRef = useRef<THREE.Group>(null);
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);
  const { playHit } = useAudio();

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.position.z = Math.sin(state.clock.elapsedTime * 0.3) * 0.3;
    }
  });

  const projects = [
    {
      title: "E-commerce Platform",
      description: "Modern React-based shopping experience",
      tech: "React, Node.js, MongoDB",
      color: "#f59e0b"
    },
    {
      title: "3D Portfolio",
      description: "Interactive Three.js showcase",
      tech: "Three.js, React, TypeScript",
      color: "#ffd700"
    },
    {
      title: "Dashboard Analytics",
      description: "Real-time data visualization",
      tech: "React, D3.js, Express",
      color: "#b8860b"
    },
    {
      title: "Mobile App",
      description: "Cross-platform mobile solution",
      tech: "React Native, Firebase",
      color: "#d4af37"
    }
  ];

  const handleProjectHover = (index: number | null) => {
    setHoveredProject(index);
    if (index !== null) {
      playHit();
    }
  };

  return (
    <group ref={groupRef} position={[-8, 0, 0]}>
      {/* Main panel */}
      <mesh position={[0, 0, 0]}>
        <planeGeometry args={[8, 10]} />
        <meshStandardMaterial
          color={new THREE.Color().setHSL(0.15, 0.3, 0.1)}
          transparent
          opacity={0.8}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Title */}
      <Text
        position={[0, 4, 0.1]}
        fontSize={0.8}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        PROJECTS
      </Text>

      {/* Project cards */}
      {projects.map((project, index) => {
        const yPosition = 2 - index * 1.5;
        const isHovered = hoveredProject === index;

        return (
          <group key={index} position={[0, yPosition, isHovered ? 0.2 : 0.1]}>
            {/* Card background */}
            <mesh
              onPointerEnter={() => handleProjectHover(index)}
              onPointerLeave={() => handleProjectHover(null)}
            >
              <planeGeometry args={[6, 1.2]} />
              <meshStandardMaterial
                color={isHovered ? project.color : "#2d2d0a"}
                transparent
                opacity={isHovered ? 0.9 : 0.7}
                emissive={isHovered ? project.color : "#000000"}
                emissiveIntensity={isHovered ? 0.2 : 0}
              />
            </mesh>

            {/* Project title */}
            <Text
              position={[0, 0.2, 0.01]}
              fontSize={0.25}
              color="#ffffff"
              anchorX="center"
              anchorY="middle"
              font="/fonts/inter.json"
            >
              {project.title}
            </Text>

            {/* Project description */}
            <Text
              position={[0, -0.1, 0.01]}
              fontSize={0.15}
              color="#d4af37"
              anchorX="center"
              anchorY="middle"
              font="/fonts/inter.json"
            >
              {project.description}
            </Text>

            {/* Tech stack */}
            <Text
              position={[0, -0.35, 0.01]}
              fontSize={0.12}
              color={project.color}
              anchorX="center"
              anchorY="middle"
              font="/fonts/inter.json"
            >
              {project.tech}
            </Text>

            {/* Hover glow effect */}
            {isHovered && (
              <mesh position={[0, 0, -0.01]}>
                <planeGeometry args={[6.5, 1.7]} />
                <meshBasicMaterial
                  color={project.color}
                  transparent
                  opacity={0.2}
                />
              </mesh>
            )}
          </group>
        );
      })}
    </group>
  );
}
