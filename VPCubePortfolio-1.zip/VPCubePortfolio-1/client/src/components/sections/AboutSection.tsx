import { Text, Box, Sphere } from "@react-three/drei";
import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export default function AboutSection() {
  const groupRef = useRef<THREE.Group>(null);
  const particlesRef = useRef<THREE.Points>(null);

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.position.x = Math.sin(state.clock.elapsedTime * 0.2) * 0.5;
    }
    
    if (particlesRef.current) {
      particlesRef.current.rotation.y += delta * 0.1;
    }
  });

  // Create particle system
  const particleCount = 100;
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 20;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 20;
  }

  return (
    <group ref={groupRef} position={[8, 0, 0]}>
      {/* Background particles */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={particleCount}
            array={positions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.05}
          color="#ffd700"
          transparent
          opacity={0.6}
          sizeAttenuation
        />
      </points>

      {/* Main panel */}
      <mesh position={[0, 0, 0]}>
        <planeGeometry args={[6, 8]} />
        <meshStandardMaterial
          color={new THREE.Color().setHSL(0.15, 0.3, 0.1)}
          transparent
          opacity={0.8}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Title */}
      <Text
        position={[0, 3, 0.1]}
        fontSize={0.8}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        ABOUT ME
      </Text>

      {/* Content */}
      <Text
        position={[0, 1.5, 0.1]}
        fontSize={0.25}
        color="#d4af37"
        anchorX="center"
        anchorY="middle"
        maxWidth={5}
        textAlign="center"
        font="/fonts/inter.json"
      >
        I'm Vaibhav Pamnani, a passionate web designer{'\n'}
        and developer with expertise in creating{'\n'}
        immersive digital experiences.{'\n\n'}
        
        With years of experience in modern web{'\n'}
        technologies, I specialize in React, Three.js,{'\n'}
        and cutting-edge frontend development.
      </Text>

      {/* Skills highlight spheres */}
      {['React', 'Three.js', 'TypeScript', 'Node.js'].map((skill, index) => {
        const angle = (index / 4) * Math.PI * 2;
        const radius = 3;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;

        return (
          <group key={skill} position={[x, -2, z]}>
            <Sphere args={[0.3]} position={[0, 0, 0]}>
              <meshStandardMaterial
                color="#ffd700"
                emissive="#ffd700"
                emissiveIntensity={0.2}
                transparent
                opacity={0.8}
              />
            </Sphere>
            <Text
              position={[0, -0.8, 0]}
              fontSize={0.2}
              color="#ffffff"
              anchorX="center"
              anchorY="middle"
              font="/fonts/inter.json"
            >
              {skill}
            </Text>
          </group>
        );
      })}
    </group>
  );
}
