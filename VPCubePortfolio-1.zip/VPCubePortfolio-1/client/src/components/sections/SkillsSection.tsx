import { Text, Torus, Sphere } from "@react-three/drei";
import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export default function SkillsSection() {
  const groupRef = useRef<THREE.Group>(null);
  const skillRingsRef = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.4) * 0.2;
    }
    
    if (skillRingsRef.current) {
      skillRingsRef.current.rotation.y += delta * 0.2;
      skillRingsRef.current.rotation.x += delta * 0.1;
    }
  });

  const skillCategories = [
    {
      category: "Frontend",
      skills: ["React", "Three.js", "TypeScript", "CSS3"],
      color: "#ffd700",
      radius: 2
    },
    {
      category: "Backend",
      skills: ["Node.js", "Express", "MongoDB", "PostgreSQL"],
      color: "#f59e0b",
      radius: 2.8
    },
    {
      category: "Tools",
      skills: ["Git", "Docker", "AWS", "Figma"],
      color: "#b8860b",
      radius: 3.6
    }
  ];

  return (
    <group ref={groupRef} position={[0, 0, -8]}>
      {/* Main panel */}
      <mesh position={[0, 0, 0]}>
        <planeGeometry args={[10, 8]} />
        <meshStandardMaterial
          color={new THREE.Color().setHSL(0.15, 0.3, 0.1)}
          transparent
          opacity={0.8}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Title */}
      <Text
        position={[0, 3.5, 0.1]}
        fontSize={0.8}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        SKILLS
      </Text>

      {/* Rotating skill rings */}
      <group ref={skillRingsRef} position={[0, 0, 0.5]}>
        {skillCategories.map((category, categoryIndex) => (
          <group key={category.category}>
            {/* Category ring */}
            <Torus args={[category.radius, 0.05, 16, 100]} position={[0, 0, 0]}>
              <meshStandardMaterial
                color={category.color}
                emissive={category.color}
                emissiveIntensity={0.3}
                transparent
                opacity={0.8}
              />
            </Torus>

            {/* Skills as spheres on the ring */}
            {category.skills.map((skill, skillIndex) => {
              const angle = (skillIndex / category.skills.length) * Math.PI * 2;
              const x = Math.cos(angle) * category.radius;
              const z = Math.sin(angle) * category.radius;

              return (
                <group key={skill} position={[x, 0, z]}>
                  <Sphere args={[0.15]} position={[0, 0, 0]}>
                    <meshStandardMaterial
                      color={category.color}
                      emissive={category.color}
                      emissiveIntensity={0.4}
                      transparent
                      opacity={0.9}
                    />
                  </Sphere>
                  
                  {/* Skill label */}
                  <Text
                    position={[0, 0.4, 0]}
                    fontSize={0.15}
                    color="#ffffff"
                    anchorX="center"
                    anchorY="middle"
                    font="/fonts/inter.json"
                  >
                    {skill}
                  </Text>
                </group>
              );
            })}

            {/* Category label */}
            <Text
              position={[0, category.radius + 0.8, 0]}
              fontSize={0.3}
              color={category.color}
              anchorX="center"
              anchorY="middle"
              font="/fonts/inter.json"
            >
              {category.category}
            </Text>
          </group>
        ))}
      </group>

      {/* Central core */}
      <Sphere args={[0.3]} position={[0, 0, 0.5]}>
        <meshStandardMaterial
          color="#ffffff"
          emissive="#ffffff"
          emissiveIntensity={0.5}
          transparent
          opacity={0.8}
        />
      </Sphere>
    </group>
  );
}
