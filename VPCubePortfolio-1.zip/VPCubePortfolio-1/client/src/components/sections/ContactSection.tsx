import { Text, Box, Sphere } from "@react-three/drei";
import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useAudio } from "../../lib/stores/useAudio";

export default function ContactSection() {
  const groupRef = useRef<THREE.Group>(null);
  const [hoveredContact, setHoveredContact] = useState<number | null>(null);
  const { playHit } = useAudio();

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.position.x = Math.cos(state.clock.elapsedTime * 0.2) * 0.3;
    }
  });

  const contactMethods = [
    {
      type: "Email",
      value: "vaibhav@example.com",
      icon: "✉",
      color: "#ffd700"
    },
    {
      type: "LinkedIn",
      value: "/in/vaibhav-pamnani",
      icon: "💼",
      color: "#f59e0b"
    },
    {
      type: "GitHub",
      value: "/vaibhav-dev",
      icon: "💻",
      color: "#b8860b"
    },
    {
      type: "Portfolio",
      value: "www.vaibhav.dev",
      icon: "🌐",
      color: "#d4af37"
    }
  ];

  const handleContactHover = (index: number | null) => {
    setHoveredContact(index);
    if (index !== null) {
      playHit();
    }
  };

  return (
    <group ref={groupRef} position={[0, 0, 8]}>
      {/* Main panel */}
      <mesh position={[0, 0, 0]}>
        <planeGeometry args={[8, 10]} />
        <meshStandardMaterial
          color={new THREE.Color().setHSL(0.15, 0.3, 0.1)}
          transparent
          opacity={0.8}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Title */}
      <Text
        position={[0, 4, 0.1]}
        fontSize={0.8}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        CONTACT
      </Text>

      {/* Subtitle */}
      <Text
        position={[0, 3.2, 0.1]}
        fontSize={0.25}
        color="#d4af37"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter.json"
      >
        Let's work together
      </Text>

      {/* Contact methods */}
      {contactMethods.map((contact, index) => {
        const yPosition = 1.5 - index * 1;
        const isHovered = hoveredContact === index;

        return (
          <group key={index} position={[0, yPosition, isHovered ? 0.3 : 0.1]}>
            {/* Card background */}
            <mesh
              onPointerEnter={() => handleContactHover(index)}
              onPointerLeave={() => handleContactHover(null)}
            >
              <planeGeometry args={[6, 0.8]} />
              <meshStandardMaterial
                color={isHovered ? contact.color : "#2d2d0a"}
                transparent
                opacity={isHovered ? 0.9 : 0.7}
                emissive={isHovered ? contact.color : "#000000"}
                emissiveIntensity={isHovered ? 0.2 : 0}
              />
            </mesh>

            {/* Icon sphere */}
            <Sphere args={[0.15]} position={[-2, 0, 0.01]}>
              <meshStandardMaterial
                color={contact.color}
                emissive={contact.color}
                emissiveIntensity={0.3}
                transparent
                opacity={0.8}
              />
            </Sphere>

            {/* Contact type */}
            <Text
              position={[-1.2, 0.1, 0.01]}
              fontSize={0.2}
              color="#ffffff"
              anchorX="left"
              anchorY="middle"
              font="/fonts/inter.json"
            >
              {contact.type}
            </Text>

            {/* Contact value */}
            <Text
              position={[-1.2, -0.15, 0.01]}
              fontSize={0.15}
              color={contact.color}
              anchorX="left"
              anchorY="middle"
              font="/fonts/inter.json"
            >
              {contact.value}
            </Text>

            {/* Hover glow effect */}
            {isHovered && (
              <mesh position={[0, 0, -0.01]}>
                <planeGeometry args={[6.5, 1.3]} />
                <meshBasicMaterial
                  color={contact.color}
                  transparent
                  opacity={0.2}
                />
              </mesh>
            )}
          </group>
        );
      })}

      {/* Floating contact icons */}
      {Array.from({ length: 8 }, (_, i) => {
        const angle = (i / 8) * Math.PI * 2;
        const radius = 4 + Math.sin(i) * 0.5;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        const y = Math.sin(i * 2) * 0.5;

        return (
          <Sphere key={i} args={[0.05]} position={[x, y, z]}>
            <meshStandardMaterial
              color="#ffd700"
              emissive="#ffd700"
              emissiveIntensity={0.5}
              transparent
              opacity={0.6}
            />
          </Sphere>
        );
      })}
    </group>
  );
}
