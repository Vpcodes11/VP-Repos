import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type PortfolioSection = "home" | "about" | "projects" | "skills" | "contact";

interface PortfolioState {
  currentSection: PortfolioSection;
  isLoading: boolean;
  
  // Actions
  setCurrentSection: (section: PortfolioSection) => void;
  setLoading: (loading: boolean) => void;
}

export const usePortfolio = create<PortfolioState>()(
  subscribeWithSelector((set) => ({
    currentSection: "home",
    isLoading: true,
    
    setCurrentSection: (section) => {
      set({ currentSection: section });
    },
    
    setLoading: (loading) => {
      set({ isLoading: loading });
    }
  }))
);
